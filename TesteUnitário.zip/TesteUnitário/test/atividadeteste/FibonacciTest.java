package atividadeteste;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
/* Caio Cesar Costa RA:31726810 */
public class FibonacciTest {

    public FibonacciTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /* Teste do fibonacci.*/
    @Test
    public void testDeterminaPosicaoFibonacci() {
        System.out.println("DeterminaPosicaoFibonacci");
        int posicao = 6;
        Fibonacci instance = new Fibonacci();
        int expResult = 8;
        int result = instance.DeterminaPosicaoFibonacci(posicao);
        assertEquals(expResult, result);
    }

    @Test
        public void testDeterminaPosicaoFibonacciNegativo() {
        System.out.println("DeterminaPosicaoFibonacciNegativo");
        int posicao = -2;
        Fibonacci instance = new Fibonacci();
        int expResult = 0;
        int result = instance.DeterminaPosicaoFibonacci(posicao);
        assertEquals(expResult, result);
        fail("ERROR: posicao deve ser maior que 0.");
    }

    @Test
        public void testDeterminaPosicaoFibonacciLetra() {
        System.out.println("DeterminaPosicaoFibonacciLetra");
        int posicao = a;
        Fibonacci instance = new Fibonacci();
        int expResult = 0;
        int result = instance.DeterminaPosicaoFibonacci(posicao);
        assertEquals(expResult, result);
        fail("ERROR: Entre com um numero inteiro positivo.");
    }

}
