package atividadeteste;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
/* Caio Cesar Costa RA:31726810 */
public class TrianguloTest {

    public TrianguloTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /* teste para determinar qual o tipo do triângulo. */
    @Test
    public void testDeterminaTipoTrianguloInexistente() {
        System.out.println("DeterminaTipoTrianguloInexistente");
        int a = 0;
        int b = 0;
        int c = 0;
        Triangulo instance = new Triangulo();
        String expResult = "INEXISTENTE";
        String result = instance.DeterminaTipoTriangulo(a, b, c);
        assertEquals(expResult, result);
    }

    @Test
    public void testDeterminaTipoTrianguloInexistente2() {
        System.out.println("DeterminaTipoTrianguloInexistente2");
        int a = 1;
        int b = 2;
        int c = 3;
        Triangulo instance = new Triangulo();
        String expResult = "INEXISTENTE";
        String result = instance.DeterminaTipoTriangulo(a, b, c);
        assertEquals(expResult, result);
    }

    @Test
    public void testDeterminaTipoTrianguloEquilatero() {
        System.out.println("DeterminaTipoTrianguloEquilatero");
        int a = 1;
        int b = 1;
        int c = 1;
        Triangulo instance = new Triangulo();
        String expResult = "EQUILATERO";
        String result = instance.DeterminaTipoTriangulo(a, b, c);
        assertEquals(expResult, result);
    }

    @Test
    public void testDeterminaTipoTrianguloIsosceles() {
        System.out.println("DeterminaTipoTrianguloIsosceles");
        int a = 1;
        int b = 2;
        int c = 2;
        Triangulo instance = new Triangulo();
        String expResult = "ISOSCELES";
        String result = instance.DeterminaTipoTriangulo(a, b, c);
        assertEquals(expResult, result);
    }

    @Test
    public void testDeterminaTipoTrianguloIsosceles2() {
        System.out.println("DeterminaTipoTrianguloIsosceles2");
        int a = 2;
        int b = 2;
        int c = 1;
        Triangulo instance = new Triangulo();
        String expResult = "ISOSCELES";
        String result = instance.DeterminaTipoTriangulo(a, b, c);
        assertEquals(expResult, result);
    }

    @Test
    public void testDeterminaTipoTrianguloEscaleno() {
        System.out.println("DeterminaTipoTrianguloEscaleno");
        int a = 2;
        int b = 3;
        int c = 4;
        Triangulo instance = new Triangulo();
        String expResult = "ESCALENO";
        String result = instance.DeterminaTipoTriangulo(a, b, c);
        assertEquals(expResult, result);
    }
}
