
package atividadeteste;
/* Caio Cesar Costa RA:31726810 */
public class Fibonacci {

    public int DeterminaPosicaoFibonacci(int n) {

        if (n < 2) {
            return n;
        } else {
            return DeterminaPosicaoFibonacci(n - 1) + DeterminaPosicaoFibonacci(n - 2);
        }
    }

}

